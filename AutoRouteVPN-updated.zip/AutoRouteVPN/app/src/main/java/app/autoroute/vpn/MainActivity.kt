package app.autoroute.vpn

import android.content.Intent
import android.net.VpnService
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.lifecycle.lifecycleScope
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.ContentPaste
import androidx.compose.material.icons.filled.PowerSettingsNew
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.wireguard.android.backend.GoBackend
import com.wireguard.android.backend.Tunnel
import com.wireguard.config.Config
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.ByteArrayInputStream
import java.net.HttpURLConnection
import java.net.URL
import kotlin.system.measureTimeMillis

data class VpnProfile(
    val name: String,
    val rawConfig: String,
    val endpoint: String
)

class MainActivity : ComponentActivity() {
    private lateinit var backend: GoBackend
    private var pendingConfig: String? = null

    private val vpnConsent = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) {
        if (it.resultCode == RESULT_OK) {
            pendingConfig?.let { raw -> connectRaw(raw) }
        }
    }

    private val importConfig = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            try {
                val raw = contentResolver.openInputStream(uri)?.bufferedReader()?.use { it.readText() }
                    ?: error("فایل خوانده نشد")
                // Validate immediately; do not save credentials outside app-private memory.
                Config.parse(ByteArrayInputStream(raw.toByteArray()))
                val endpoint = Regex("""(?m)^\s*Endpoint\s*=\s*([^\s#]+)""")
                    .find(raw)?.groupValues?.get(1) ?: "Endpoint نامشخص"
                profilesState.value = profilesState.value + VpnProfile(
                    name = endpoint.substringBefore(':').take(40),
                    rawConfig = raw,
                    endpoint = endpoint
                )
                statusState.value = "پیکربندی معتبر وارد شد؛ برای اتصال، سرور را انتخاب کن."
            } catch (e: Exception) {
                statusState.value = "فایل معتبر WireGuard نیست: ${e.message ?: "خطای ناشناخته"}"
            }
        }
    }

    private val profilesState = mutableStateOf<List<VpnProfile>>(emptyList())
    private val candidateIpsState = mutableStateOf<List<String>>(emptyList())
    private val statusState = mutableStateOf("برای شروع، یک فایل معتبر WireGuard با پسوند .conf وارد کن.")
    private val connectedState = mutableStateOf(false)
    private val activeNameState = mutableStateOf<String?>(null)
    private val latencyState = mutableStateOf<Long?>(null)
    private val busyState = mutableStateOf(false)
    private var activeTunnel: AppTunnel? = null
    private var activeConfig: Config? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        backend = GoBackend(applicationContext)
        setContent {
            AutoRouteTheme {
                AutoRouteScreen(
                    profiles = profilesState.value,
                    candidateIps = candidateIpsState.value,
                    onAddIp = { ip ->
                        if (isValidIpOrHost(ip)) {
                            candidateIpsState.value = (candidateIpsState.value + ip).distinct()
                            statusState.value = "آدرس به فهرست بررسی اضافه شد. برای اتصال VPN، پیکربندی کامل WireGuard لازم است."
                        } else statusState.value = "آدرس IP معتبر نیست."
                    },
                    status = statusState.value,
                    connected = connectedState.value,
                    activeName = activeNameState.value,
                    latency = latencyState.value,
                    busy = busyState.value,
                    onImport = { importConfig.launch(arrayOf("text/*", "application/octet-stream", "*/*")) },
                    onConnect = { profile -> askPermissionAndConnect(profile) },
                    onDisconnect = { disconnect() },
                    onAutoSelect = { autoSelect() }
                )
            }
        }
    }

    private fun isValidIpOrHost(value: String): Boolean {
        val v = value.trim()
        if (v.isEmpty() || v.length > 253 || v.any { it.isWhitespace() }) return false
        val ipv4 = v.matches(Regex("""^(25[0-5]|2[0-4]\\d|1?\\d?\\d)(\\.(25[0-5]|2[0-4]\\d|1?\\d?\\d)){3}$"""))
        val ipv6 = v.contains(":") && v.matches(Regex("""^[0-9a-fA-F:]+$"""))
        val host = v.matches(Regex("""^(?=.{1,253}$)([a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)(\\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)*$"""))
        return ipv4 || ipv6 || host
    }

    private fun askPermissionAndConnect(profile: VpnProfile) {
        try {
            Config.parse(ByteArrayInputStream(profile.rawConfig.toByteArray()))
            val intent = VpnService.prepare(this)
            if (intent != null) {
                pendingConfig = profile.rawConfig
                vpnConsent.launch(intent)
            } else {
                connectRaw(profile.rawConfig)
            }
        } catch (e: Exception) {
            statusState.value = "پیکربندی قابل استفاده نیست: ${e.message}"
        }
    }

    private fun connectRaw(raw: String) {
        lifecycleScope.launch {
            busyState.value = true
            statusState.value = "در حال برقراری تونل واقعی WireGuard…"
            try {
                withContext(Dispatchers.IO) {
                    val config = Config.parse(ByteArrayInputStream(raw.toByteArray()))
                    val tunnel = AppTunnel("AutoRoute-${System.currentTimeMillis()}")
                    backend.setState(tunnel, Tunnel.State.UP, config)
                    activeTunnel = tunnel
                    activeConfig = config
                }
                connectedState.value = true
                activeNameState.value = activeTunnel?.name
                statusState.value = "تونل WireGuard فعال شد. این وضعیت به معنی تضمین دسترسی به همهٔ مقصدها نیست."
                latencyState.value = probeHttpsLatency()
            } catch (e: Exception) {
                connectedState.value = false
                statusState.value = "اتصال ناموفق: ${e.message ?: e.javaClass.simpleName}"
            } finally {
                busyState.value = false
            }
        }
    }

    private suspend fun probeHttpsLatency(): Long? = withContext(Dispatchers.IO) {
        // This is HTTPS response time through the app's current routing, not ICMP ping.
        try {
            var result: Long? = null
            repeat(3) {
                val elapsed = measureTimeMillis {
                    val connection = (URL("https://www.gstatic.com/generate_204").openConnection() as HttpURLConnection)
                    connection.connectTimeout = 5000
                    connection.readTimeout = 5000
                    connection.instanceFollowRedirects = false
                    try {
                        connection.requestMethod = "GET"
                        connection.responseCode
                    } finally {
                        connection.disconnect()
                    }
                }
                result = if (result == null) elapsed else ((result!! + elapsed) / 2)
            }
            result
        } catch (_: Exception) { null }
    }

    private fun disconnect() {
        lifecycleScope.launch {
            busyState.value = true
            try {
                withContext(Dispatchers.IO) {
                    val tunnel = activeTunnel
                    if (tunnel != null) backend.setState(tunnel, Tunnel.State.DOWN, null)
                }
                connectedState.value = false
                activeNameState.value = null
                latencyState.value = null
                statusState.value = "اتصال قطع شد."
            } catch (e: Exception) {
                statusState.value = "خطا هنگام قطع اتصال: ${e.message}"
            } finally {
                activeTunnel = null
                activeConfig = null
                busyState.value = false
            }
        }
    }

    private fun autoSelect() {
        val candidates = profilesState.value.toList()
        if (candidates.isEmpty()) {
            statusState.value = "ابتدا فایل‌های معتبر WireGuard را وارد کن. برنامه سرور عمومی ساختگی ندارد."
            return
        }
        statusState.value = "تست خودکار نیازمند اتصال جداگانه به هر سرور است. این نسخه برای جلوگیری از قطع ناخواسته، سرورها را خودکار جابه‌جا نمی‌کند؛ از فهرست، یک سرور را انتخاب و تست کن."
    }

    private inner class AppTunnel(private val tunnelName: String) : Tunnel {
        override fun getName(): String = tunnelName
        override fun onStateChange(newState: Tunnel.State) = Unit
    }
}

@Composable
private fun AutoRouteTheme(content: @Composable () -> Unit) {
    val colors = darkColorScheme(
        primary = androidx.compose.ui.graphics.Color(0xFF38BDF8),
        secondary = androidx.compose.ui.graphics.Color(0xFF2DD4BF),
        background = androidx.compose.ui.graphics.Color(0xFF07111F),
        surface = androidx.compose.ui.graphics.Color(0xFF101E30)
    )
    MaterialTheme(colorScheme = colors, content = content)
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun AutoRouteScreen(
    profiles: List<VpnProfile>,
    candidateIps: List<String>,
    onAddIp: (String) -> Unit,
    status: String,
    connected: Boolean,
    activeName: String?,
    latency: Long?,
    busy: Boolean,
    onImport: () -> Unit,
    onConnect: (VpnProfile) -> Unit,
    onDisconnect: () -> Unit,
    onAutoSelect: () -> Unit
) {
    var manualIp by remember { mutableStateOf("") }
    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text("AutoRoute VPN", fontWeight = FontWeight.Bold)
                        Text("انتخاب سرور و تونل واقعی WireGuard", style = MaterialTheme.typography.labelSmall)
                    }
                }
            )
        }
    ) { padding ->
        LazyColumn(
            modifier = Modifier.fillMaxSize().padding(padding).padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            item {
                Card(shape = RoundedCornerShape(24.dp), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
                    Column(Modifier.fillMaxWidth().padding(20.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                        Icon(
                            if (connected) Icons.Default.CheckCircle else Icons.Default.PowerSettingsNew,
                            contentDescription = null,
                            tint = if (connected) MaterialTheme.colorScheme.secondary else MaterialTheme.colorScheme.primary,
                            modifier = Modifier.size(56.dp)
                        )
                        Spacer(Modifier.height(8.dp))
                        Text(if (connected) "تونل فعال" else "آماده اتصال", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
                        Text(status, style = MaterialTheme.typography.bodyMedium)
                        if (latency != null) Text("زمان پاسخ HTTPS: ${latency} ms")
                        if (activeName != null) Text("تونل: $activeName")
                        Spacer(Modifier.height(12.dp))
                        if (busy) CircularProgressIndicator()
                        else if (connected) Button(onClick = onDisconnect, modifier = Modifier.fillMaxWidth()) { Text("قطع اتصال") }
                        else Button(onClick = onAutoSelect, modifier = Modifier.fillMaxWidth()) { Text("بررسی سرورها") }
                    }
                }
            }
            item {
                Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
                    Column(Modifier.fillMaxWidth().padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text("افزودن IP یا دامنه به‌صورت دستی", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                        Text("این فهرست فقط برای نگهداری آدرس‌های هدف است؛ IP به‌تنهایی اطلاعات احراز هویت و تونل VPN ندارد.", style = MaterialTheme.typography.bodySmall)
                        OutlinedTextField(
                            value = manualIp,
                            onValueChange = { manualIp = it },
                            modifier = Modifier.fillMaxWidth(),
                            singleLine = true,
                            label = { Text("مثلاً 203.0.113.10 یا vpn.example.com") },
                            placeholder = { Text("IP یا دامنه") }
                        )
                        Button(
                            onClick = {
                                val value = manualIp.trim()
                                onAddIp(value)
                                manualIp = ""
                            },
                            enabled = manualIp.isNotBlank(),
                            modifier = Modifier.fillMaxWidth()
                        ) { Text("افزودن به فهرست") }
                        Text("تعداد آدرس‌های ذخیره‌شده: ${candidateIps.size}", style = MaterialTheme.typography.labelLarge)
                        if (candidateIps.isNotEmpty()) {
                            Text("آخرین آدرس‌ها", style = MaterialTheme.typography.labelMedium)
                            candidateIps.takeLast(5).reversed().forEach { Text("• $it", style = MaterialTheme.typography.bodySmall) }
                        }
                    }
                }
            }
            item {
                Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
                    Text("پیکربندی‌های VPN من", style = MaterialTheme.typography.titleLarge, modifier = Modifier.weight(1f))
                    OutlinedButton(onClick = onImport) {
                        Icon(Icons.Default.Add, contentDescription = null)
                        Spacer(Modifier.width(6.dp))
                        Text("وارد کردن .conf")
                    }
                }
                Text("برای اتصال واقعی به یک سرور WireGuard نیاز داری. IP تنها کافی نیست.", style = MaterialTheme.typography.bodySmall)
            }
            if (profiles.isEmpty()) {
                item {
                    OutlinedCard {
                        Column(Modifier.fillMaxWidth().padding(18.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                            Icon(Icons.Default.ContentPaste, contentDescription = null, modifier = Modifier.size(36.dp))
                            Text("هنوز سروری وارد نشده")
                            Text("یک فایل WireGuard معتبر با اطلاعات سرور و کلیدهای لازم انتخاب کن.", style = MaterialTheme.typography.bodySmall)
                        }
                    }
                }
            }
            items(profiles) { profile ->
                Card {
                    Column(Modifier.fillMaxWidth().padding(16.dp)) {
                        Text(profile.name, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
                        Text(profile.endpoint, style = MaterialTheme.typography.bodySmall)
                        Spacer(Modifier.height(8.dp))
                        Button(
                            onClick = { onConnect(profile) },
                            enabled = !busy && !connected,
                            modifier = Modifier.fillMaxWidth()
                        ) { Text("اتصال به این سرور") }
                    }
                }
            }
            item {
                Text(
                    "حریم خصوصی: فایل‌های واردشده فقط در حافظهٔ همین اجرا نگهداری می‌شوند. زمان پاسخ نمایش‌داده‌شده، زمان پاسخ HTTPS است و پینگ ICMP نیست.",
                    style = MaterialTheme.typography.bodySmall
                )
            }
        }
    }
}
